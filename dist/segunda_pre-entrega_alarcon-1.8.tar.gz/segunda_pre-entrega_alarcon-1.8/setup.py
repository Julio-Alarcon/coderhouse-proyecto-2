import os
from setuptools import setup, find_packages

setup(
    name = "segunda_pre-entrega_alarcon",
    version = "1.8",
    description = "Paquete distribuido para el proyecto de CoderHouse",
    author = "Julio Alarcon Caballero",
    author_email = "julio.alarconca@gmail.com",
    packages = find_packages(["segunda_pre-entrega_alarcon"]),
)
